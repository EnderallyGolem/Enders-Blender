# EndHelper
Calling it a blender was funnier. Too lazy to change the internal names though.

Source code can be found at https://github.com/EnderallyGolem/Enders-Blender.