# EndHelper
Calling it a blender was funnier. Too lazy to change the internal names though.